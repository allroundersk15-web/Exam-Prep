EXAMSPRINT — SSC & RAILWAY MOCK PRACTICE
=======================================

WHAT'S INCLUDED
- Attractive, responsive website with animated cards and colour-coded sections.
- Built-in starter practice bank of 100 MCQs: 30 Mathematics, 30 Reasoning, 40 General Awareness / General Science.
- Each mock contains 100 questions and has a 60-minute total timer.
- Random Mixed Mock shuffles questions from the starter bank and saved mock sets; it aims for 30 Maths, 30 Reasoning, 40 GS/GA questions.
- Instructions screen appears before each mock starts.
- EN / HI language buttons; saved Hindi translations display where provided. When no Hindi translation exists, English is shown.
- Per-question time tracker, question palette, answer clearing, mark-for-review, Previous / Next.
- Timer stays green, turns yellow at 10 minutes remaining, and red at 1 minute remaining.
- Scoring: +1 correct, -0.25 incorrect, 0 unanswered.
- Results include score, accuracy, time spent per question, correct answers, explanations and short SSC/Railway solving strategies.
- Local PDF storage, text extraction for review, manual bilingual question editor, JSON question backup.
- Local IndexedDB storage; no account or cloud sync required.

IMPORTANT ABOUT QUESTION CONTENT
The 100 built-in questions are starter practice material, not an official SSC/Railway paper. Please verify answers and any imported questions before relying on them for exam preparation. Random mocks may include questions from saved question sets if their subject labels are recognised; questions labelled Practice/Mixed are distributed among sections. The mock is still exactly 100 questions.

RUN WITHOUT GITHUB — WINDOWS
1. Extract the complete ZIP to a folder.
2. Install Python 3 if needed: https://www.python.org/downloads/
3. Double-click Start-ExamSprint-Windows.bat.
4. Open http://127.0.0.1:8000/ if your browser does not open automatically (port 8001 is used if 8000 is busy).
5. Keep the server command window open while using the website.

MAC / LINUX
1. Extract the ZIP.
2. Run `python3 localhost_server.py` from the extracted folder.
3. Open http://127.0.0.1:8000/ in your browser.

ANDROID
The ZIP does not install a server app on Android. Extract the ZIP and use a trusted local web-server app to serve the `examsprint_offline` folder. Open the local address that app provides. A localhost address works only on the device running the server.

DATA & PRIVACY
- Questions, results and saved PDFs live in this browser's local IndexedDB on this device.
- Export your question sets regularly. The JSON backup does not include PDF blobs or test history.
- Clearing browser/site data can erase saved content.
- The included server binds only to 127.0.0.1 and is not a public internet website.

PDF EXTRACTION
The PDF reader loads PDF.js from a CDN, so an internet connection is needed to load it. Text extraction is imperfect; scanned/image-only pages and highlighted correct answers may need manual review. Only save questions after verifying the answer.
