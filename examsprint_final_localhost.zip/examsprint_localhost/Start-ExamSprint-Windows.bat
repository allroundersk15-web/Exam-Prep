@echo off
setlocal
cd /d "%~dp0examsprint_offline"
where py >nul 2>nul
if %errorlevel%==0 (
  start "ExamSprint local server" cmd /k "py -3 ..\localhost_server.py"
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    start "ExamSprint local server" cmd /k "python ..\localhost_server.py"
  ) else (
    echo Python was not found. Install Python 3 from https://www.python.org/downloads/ and try again.
    pause
  )
)
