EXAMSPRINT — RUN LOCALLY WITHOUT GITHUB
======================================

This is a local website package. It does not need GitHub, hosting, or an account. It does not create a public internet link.

WINDOWS (EASIEST)
1. Download and extract the complete ZIP.
2. Install Python 3 if it is not already installed: https://www.python.org/downloads/
3. Double-click Start-ExamSprint-Windows.bat.
4. Your browser should open. If not, visit http://127.0.0.1:8000/ (or http://127.0.0.1:8001/ if port 8000 is busy).
5. Keep the server command window open while using ExamSprint.

MAC / LINUX
1. Extract the ZIP.
2. Run `python3 localhost_server.py` from the extracted folder.
3. Open http://127.0.0.1:8000/ in your browser.

ANDROID PHONE
This ZIP cannot install a server app on Android by itself. Extract it and use a trusted local web-server app to serve the `examsprint_offline` folder, then open the address shown by that app. `127.0.0.1` only works on the device where the server is running.

WHAT THE SITE INCLUDES
- Attractive animated dashboard and responsive mobile layout.
- Instructions page before every mock.
- 100 MCQs per mock: 30 Maths, 30 Reasoning, 40 GS/GA; 60 minutes total.
- Randomized questions from the built-in practice bank and your saved question sets.
- Green timer, yellow in the final 10 minutes, red in the final minute.
- EN / HI language switch; Hindi displays for questions with a saved Hindi translation.
- Per-question time tracker, question palette, Previous/Next, clear answer, mark for review.
- +1 / -0.25 scoring and results with time per question, correct answer, explanation, and short SSC/Railway strategy.
- Manual question editor, PDF storage and text extraction review, JSON backup.

IMPORTANT
The included 100 questions are starter practice content, not an official exam paper. Check answers and imported text before relying on them. The PDF reader loads PDF.js from a CDN and requires internet when first used. Scanned pages and answer highlights may need manual review.

DATA & PRIVACY
Questions, results, and PDFs are stored in your browser on this device. Export question backups regularly; JSON backups exclude PDFs and history. Clearing browser/site data can erase local content. The Python server binds to 127.0.0.1 only; do not change that setting unless you intentionally want other devices to connect.
