#!/bin/sh
cd "$(dirname "$0")"
python3 localhost_server.py
