#!/usr/bin/env python3
"""Tiny local-only server for the ExamSprint personal practice website."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os, socket, webbrowser

ROOT = Path(__file__).resolve().parent / "examsprint_offline"
os.chdir(ROOT)
HOST = "127.0.0.1"
PORT = 8000

class Handler(SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print("[ExamSprint] " + (fmt % args))

try:
    server = ThreadingHTTPServer((HOST, PORT), Handler)
except OSError:
    PORT = 8001
    server = ThreadingHTTPServer((HOST, PORT), Handler)
url = f"http://{HOST}:{PORT}/"
print("\nExamSprint is running on this device only.")
print("Open this address in your browser:", url)
print("Keep this window open while using the website.")
print("Press Ctrl+C to stop the local server.\n")
try:
    webbrowser.open(url)
except Exception:
    pass
try:
    server.serve_forever()
except KeyboardInterrupt:
    print("\nExamSprint local server stopped.")
finally:
    server.server_close()
