/* Local database: IndexedDB keeps PDF blobs and saved tests in this browser. */
const ExamDB = (() => {
  const DB_NAME = "examsprint-local-v1";
  let dbPromise;
  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains("papers")) db.createObjectStore("papers", {keyPath:"id", autoIncrement:true});
        if (!db.objectStoreNames.contains("tests")) db.createObjectStore("tests", {keyPath:"id", autoIncrement:true});
        if (!db.objectStoreNames.contains("history")) db.createObjectStore("history", {keyPath:"id", autoIncrement:true});
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }
  async function all(store) {
    const db = await open();
    return new Promise((resolve,reject) => {
      const req = db.transaction(store,"readonly").objectStore(store).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }
  async function add(store, value) {
    const db = await open();
    return new Promise((resolve,reject) => {
      const req = db.transaction(store,"readwrite").objectStore(store).add(value);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function put(store, value) {
    const db = await open();
    return new Promise((resolve,reject) => {
      const req = db.transaction(store,"readwrite").objectStore(store).put(value);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function remove(store, id) {
    const db = await open();
    return new Promise((resolve,reject) => {
      const req = db.transaction(store,"readwrite").objectStore(store).delete(Number(id));
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }
  async function get(store, id) {
    const db = await open();
    return new Promise((resolve,reject) => {
      const req = db.transaction(store,"readonly").objectStore(store).get(Number(id));
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  return {all,add,put,remove,get};
})();